
/**
 * A program to add two numbers and print them out
 * 
 * @author Sue Grice
 * @version 12/2/07
 */
public class tutorial1
{
    //instance variables otherwiase known as global variables
    private int number1;
    private int anotherNumber;
    private int total;

    /**
     * Constructor for objects of class tutorial1
     */
    public tutorial1()
    {
        //initialise the instance variables
        number1 = 9;
        anotherNumber = 2;
        total = 0;
    }

    //The main method is the starting point for all Java programs, BlueJ will allow you to run a program without one but
    //it is good practise to use it. This will allow non-BlueJ users to run your program.
    public static void main(String [] args)//String [] args will be explained later, all you need to know is that you need to have it.
    {
        //This will create a new instance of the tutorial1 class and run the constructor
        tutorial1 t = new tutorial1();
        
        // this calls and runs runMethods() 
        t.runMethods();
    }
    
    
    
    /**
     * runMethods this class calls all the other methods to run them
     *
     * @param  none
     * @return none
     */
    public void runMethods()
    {
        
       addNumbers();
       printNumbers();
    }
    
    
    
   /**
    * addNumbers - sums two numbers
    *
    * @param  none
    * @return none    
    */
   public void addNumbers()
   {
      total = number1 + anotherNumber;
   }
   
   
    /**
     * prints out a string and the total
     *
     * @param  none
     * @return none
     */
    public void printNumbers()
    {
        System.out.println("the total of the two numbers is "+total);
    }
    
    
    /**
     * a method to retrun the total. this method would be used by other classes.
     *
     * @param  none
     * @return int total
     */
    public int getTotal()
    {
        return total;
    }
    
    
  
}

